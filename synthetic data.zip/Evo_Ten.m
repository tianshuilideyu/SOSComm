function [ network_snapshot,network_ground ] = Evo_Ten( network_snapshot,network_ground,evo_percent)
%EVO_TEN Summary of this function goes here
%   Detailed explanation goes here
% network_snapshot ��ǰ�������
% network_ground ��׼
% evo_percent �仯�İٷֱ�
% new_per �������ٷֱ�
% old_per ��ʧ����ٷֱ�

N=size(network_ground,2);
Tensor_size = network_snapshot{1,1};
Tensor_subs = network_snapshot{1,2};
Tensor_subs_tem = Tensor_subs;
Tensor_vals = network_snapshot{1,3};
for n=1:N %evolution
        evo_num = ceil(Tensor_size(n)*evo_percent);
        r = randi(Tensor_size(n),1,evo_num);
        tem = network_ground{1,n}(r,:);
        idx = cell(1,evo_num);
        for i=1:evo_num-1
            network_ground{1,n}(r(i),:)=tem(i+1,:);
            idx{1,i} = find(Tensor_subs_tem(:,n)==r(i));
            Tensor_subs(idx{1,i},n)=r(i+1);
        end
        network_ground{1,n}(r(evo_num),:)=tem(1,:);
        idx{1,evo_num} = find(Tensor_subs_tem(:,n)==r(evo_num));
        Tensor_subs(idx{1,evo_num},n)=r(1);
end
network_snapshot{1,1}=Tensor_size;
network_snapshot{1,2}=Tensor_subs;
network_snapshot{1,3}=Tensor_vals;

end

