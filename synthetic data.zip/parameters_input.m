function [ Tensor_size,Tensor_subs,Tensor_vals,J,N,K,U_groundtruth,D] = parameters_input( S,N,K,D)
%PARAMETERS_INPUT Summary of this function goes here
%   Detailed explanation goes here
% the parameters for generate synthetic datasets
% S is the size
% N is the number of types
% K is the clusters number
% D is the desity 0.5%��0.05%
% J is the number of nonzero elements in tensor

 Tensor_size = S;
 J = 1;
 U_groundtruth = {};
 for i=1:N
     ui = zeros(Tensor_size(i),K);
     U_groundtruth{1,i} = ui;
     J = J*S(i);
     clear ui;
 end
 
 J = ceil(J*D);
 Tensor_subs = zeros(J,N);
 Tensor_vals = ones(J,1);
 
end

