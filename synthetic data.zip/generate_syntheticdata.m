% generate the synthetic dataset
clear;
clc;
expn = 0.95;% expn is the parameter for Zipf's law

% S = [1000,1000];N = 2;K = 2;D=0.001;
% [ Tensor_size,Tensor_subs,Tensor_vals,J,N,K,U_groundtruth,D ] = parameters_input( S,N,K,D );
% % % % %  
% S = [1000,10000];N = 2;K = 4;D=0.0001;
% [ Tensor_size,Tensor_subs,Tensor_vals,J,N,K,U_groundtruth,D ] = parameters_input( S,N,K,D );

% % %  
% S = [100,100,100,100];N = 4;K = 2; D=0.001;
% [ Tensor_size,Tensor_subs,Tensor_vals,J,N,K,U_groundtruth,D ] = parameters_input( S,N,K,D );
% % 
S = [100,100,100,1000];N =4;K = 4; D=0.0001;
[ Tensor_size,Tensor_subs,Tensor_vals,J,N,K,U_groundtruth,D ] = parameters_input(S,N,K,D );

%%  generate data

for n=1:N
    tem = Tensor_size(n)/K;
    nnz = J/K;
    for k=1:K
        U_groundtruth{1,n}(ceil(tem*(k-1)+1):ceil(tem*k),k)=1;
        Tensor_subs(ceil(nnz*(k-1)+1):ceil(nnz*k),n)=zipf_rand(ceil(tem*k)-ceil(tem*(k-1)+1)+1,expn,ceil(nnz*k)-ceil(nnz*(k-1)+1)+1)+ceil(tem*(k-1));
    end
end

network_snapshot = cell(1,3);
network_snapshot{1,1}=Tensor_size;
network_snapshot{1,2}=Tensor_subs;
network_snapshot{1,3}=Tensor_vals;
network_ground = cell(1,10);
network_ground{1,1}=U_groundtruth;
synthetic_network = cell(1,10);
synthetic_network{1,1}=network_snapshot;
for t=2:10 %timestamp
    %EVO
    evo_per = (5 + (10-5).*rand(1,1))/100;    
    [synthetic_network{1,t},network_ground{1,t}]=Evo_Ten(synthetic_network{1,t-1},network_ground{1,t-1},evo_per);
    
    %NEW AND OLD OBJECT
    new_per = (10+(15-10).*rand(1,1))/100;
    old_per = (10+(15-10).*rand(1,1))/100;
    [synthetic_network{1,t},network_ground{1,t}]=New_old(synthetic_network{1,t-1},network_ground{1,t-1},new_per,old_per);
end



%% save data
save('synthetic_data.mat','N','K','synthetic_network','network_ground');


    
        
        